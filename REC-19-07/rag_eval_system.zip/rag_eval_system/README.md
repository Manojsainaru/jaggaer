# Multi-Document RAG System

This repository contains a robust Multi-Document Retrieval-Augmented Generation (RAG) and evaluation pipeline. It combines state-of-the-art open-source embeddings, hybrid retrieval, and cross-encoder reranking to accurately answer complex queries across extensive PDF documents (like SEC 10-Q filings).

## 🚀 Architecture Overview

The pipeline executes the following steps:

1. **Ingestion & Chunking (`ingest.py`)**: 
   - Uses Langchain's `PyPDFLoader` to read PDF documents from the `data/` directory.
   - Splits text using `RecursiveCharacterTextSplitter` while strictly preserving the source document's filename in the metadata.
2. **Intelligent Caching (`index_manager.py`)**:
   - Computes a SHA-256 hash of your document contents.
   - If the documents haven't changed, it automatically loads the cached FAISS index from disk, saving you massive amounts of time on re-embedding!
3. **Embeddings & Vector Store**: 
   - Embedded using **Qwen** (`Qwen/Qwen3-Embedding-0.6B`) running locally via PyTorch.
   - Stored in a local **FAISS** index for dense retrieval.
4. **Hybrid Retrieval (`retriver.py`)**: 
   - An **Ensemble Retriever** combines the semantic accuracy of Dense retrieval (FAISS) with the exact keyword matching of Sparse retrieval (BM25).
5. **Cross-Encoder Reranking (`retriver.py`)**: 
   - The combined chunks are passed through the **`BAAI/bge-reranker-base`** model to intelligently re-order the contexts, ensuring only the most highly relevant chunks make it to the LLM.
6. **Generation (`main.py` & `query.py`)**: 
   - Passes the reranked context to **`gemini-2.5-flash`**. 
   - The LLM is strictly instructed to cite its sources at the end of the answer using the exact filenames (`SOURCE(S): doc1.pdf`).

## 📁 File Structure

- **`main.py`**: The primary orchestrator. Run this to interact with the fully assembled RAG pipeline.
- **`ingest.py`**: Helper functions to load and chunk PDFs.
- **`index_manager.py`**: Handles saving and loading the FAISS vector database to avoid redundant embedding compute.
- **`retriver.py`**: Builds the FAISS + BM25 Ensemble Retriever and the BAAI Cross-Encoder reranker.
- **`config.py`**: Contains dataclasses (`RetrieverConfig`, `IndexCacheConfig`, `RerankerConfig`) to easily tweak retrieval weights and top-k limits.
- **`evaluate.py`**: A specialized script for evaluating the RAG pipeline's accuracy against a ground truth Q&A CSV dataset.
- **`requirements.txt`**: Pinned Python dependencies.
- **`.env`**: Stores your API keys (like `GEMINI_API_KEY`).

## ⚙️ Installation & Setup

1. **Install Git**: Make sure Git is installed and in your system PATH.
2. **Python Environment**: We recommend using Python 3.10. A virtual environment has been provided in the `venv` directory.
3. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```
4. **Set your API Key**:
   Create a `.env` file and add your Gemini API Key:
   ```env
   GEMINI_API_KEY="your_api_key_here"
   ```

## 🧠 Usage

### Querying the System
You can execute a single query end-to-end using `main.py`. The script will automatically load your PDFs, build (or load) the cached FAISS index, retrieve, rerank, and generate the final answer.

```bash
python main.py --data-dir ../data/sec10 --query "What is the total revenue?"
```

### Evaluating the System
If you have a ground truth dataset (like `qna_data.csv`), you can run the evaluation script to measure how perfectly the system retrieves and cites the correct documents.

```bash
python evaluate.py --eval-csv qna_data.csv --num-samples 10
```
